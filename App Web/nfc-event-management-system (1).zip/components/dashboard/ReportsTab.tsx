
import React from 'react';
import { Event, Transaction, User, Card as CardType, TransactionType } from '../../types';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';

interface ReportsTabProps {
    event: Event;
    transactions: Transaction[];
    users: User[];
    cards: CardType[];
}

const ReportsTab: React.FC<ReportsTabProps> = ({ event, transactions, users, cards }) => {
    const usersMap = new Map(users.map(u => [u.id, u]));
    const cardsMap = new Map(cards.map(c => [c.uid, c]));

    const downloadCSV = (csvContent: string, fileName: string) => {
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', fileName);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleDownloadSalesReport = () => {
        const salesTransactions = transactions.filter(
            tx => tx.type === TransactionType.SALE || tx.type === TransactionType.VOID
        );

        const headers = [
            'ID Transacción', 'Fecha', 'Hora', 'Tipo', 'Monto', 'Detalles / Productos',
            'ID Vendedor', 'Nombre Vendedor', 'Número Empleado',
            'UID Tarjeta Cliente', 'Número Cliente'
        ];

        const rows = salesTransactions.map(tx => {
            const user = usersMap.get(tx.userId);
            const card = cardsMap.get(tx.customerCardUid);
            return [
                tx.id,
                new Date(tx.timestamp).toLocaleDateString(),
                new Date(tx.timestamp).toLocaleTimeString(),
                tx.type,
                tx.amount.toFixed(2),
                `"${tx.details?.replace(/"/g, '""') || ''}"`,
                user?.id || 'N/A',
                user?.name || 'N/A',
                user?.employeeNumber || 'N/A',
                tx.customerCardUid,
                card?.customerNumber || 'N/A',
            ].join(',');
        });

        const csvContent = [headers.join(','), ...rows].join('\n');
        const safeEventName = event.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
        downloadCSV(csvContent, `reporte_ventas_${safeEventName}.csv`);
    };

    const handleDownloadBalanceReport = () => {
        const balanceTransactions = transactions.filter(
            tx => tx.type === TransactionType.RELOAD || tx.type === TransactionType.DEVOLUTION
        );

        const headers = [
            'ID Transacción', 'Fecha', 'Hora', 'Tipo', 'Monto',
            'ID Cajero', 'Nombre Cajero', 'Número Empleado',
            'UID Tarjeta Cliente', 'Número Cliente'
        ];

        const rows = balanceTransactions.map(tx => {
            const user = usersMap.get(tx.userId);
            const card = cardsMap.get(tx.customerCardUid);
            return [
                tx.id,
                new Date(tx.timestamp).toLocaleDateString(),
                new Date(tx.timestamp).toLocaleTimeString(),
                tx.type,
                tx.amount.toFixed(2),
                user?.id || 'N/A',
                user?.name || 'N/A',
                user?.employeeNumber || 'N/A',
                tx.customerCardUid,
                card?.customerNumber || 'N/A',
            ].join(',');
        });
        
        const csvContent = [headers.join(','), ...rows].join('\n');
        const safeEventName = event.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
        downloadCSV(csvContent, `reporte_movimientos_saldo_${safeEventName}.csv`);
    };

    const hasSalesData = transactions.some(tx => tx.type === TransactionType.SALE || tx.type === TransactionType.VOID);
    const hasBalanceData = transactions.some(tx => tx.type === TransactionType.RELOAD || tx.type === TransactionType.DEVOLUTION);

    return (
        <Card>
            <h3 className="text-xl font-semibold mb-4 text-white">Generación de Reportes</h3>
            <p className="text-gray-400 mb-6">
                Descarga informes detallados en formato CSV, compatibles con Excel y otras hojas de cálculo.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-700 p-4 rounded-lg">
                    <h4 className="font-semibold text-lg mb-2">Reporte de Ventas</h4>
                    <p className="text-sm text-gray-400 mb-4">Incluye todas las ventas y anulaciones realizadas.</p>
                    <Button onClick={handleDownloadSalesReport} disabled={!hasSalesData}>
                        {hasSalesData ? 'Descargar Ventas' : 'No hay ventas'}
                    </Button>
                </div>
                <div className="bg-gray-700 p-4 rounded-lg">
                    <h4 className="font-semibold text-lg mb-2">Reporte de Movimientos de Saldo</h4>
                    <p className="text-sm text-gray-400 mb-4">Incluye todas las recargas y devoluciones de saldo.</p>
                    <Button onClick={handleDownloadBalanceReport} disabled={!hasBalanceData}>
                        {hasBalanceData ? 'Descargar Movimientos' : 'No hay movimientos'}
                    </Button>
                </div>
            </div>
        </Card>
    );
};

export default ReportsTab;