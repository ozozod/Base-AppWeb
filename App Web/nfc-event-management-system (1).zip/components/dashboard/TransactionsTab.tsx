
import React, { useState, useMemo } from 'react';
import { Transaction, User, TransactionType } from '../../types';
import { Card } from '../ui/Card';
import { useTable } from '../../hooks/useTable';
import { Pagination } from '../ui/Pagination';
import { SortableHeader } from '../ui/SortableHeader';

interface TransactionsTabProps {
    transactions: Transaction[];
    users: User[];
}

const TransactionsTab: React.FC<TransactionsTabProps> = ({ transactions, users }) => {
    const [filterType, setFilterType] = useState<string>('');
    const [filterUser, setFilterUser] = useState<string>('');
    
    const usersMap = useMemo(() => new Map(users.map(u => [u.id, u.name])), [users]);

    const filteredTransactions = useMemo(() => {
        return transactions.filter(tx => {
            const typeMatch = filterType ? tx.type === filterType : true;
            const userMatch = filterUser ? tx.userId === filterUser : true;
            return typeMatch && userMatch;
        });
    }, [transactions, filterType, filterUser]);

    const { 
        paginatedItems, 
        requestSort, 
        sortConfig, 
        currentPage, 
        totalPages, 
        setPage 
    } = useTable(filteredTransactions, 'timestamp', 15, 'descending');

    const getTransactionTypeStyles = (type: TransactionType) => {
        switch (type) {
            case TransactionType.SALE: return 'bg-yellow-500 text-yellow-900';
            case TransactionType.RELOAD: return 'bg-green-500 text-green-900';
            case TransactionType.VOID: return 'bg-red-500 text-red-900';
            case TransactionType.DEVOLUTION: return 'bg-sky-500 text-sky-900';
            default: return 'bg-gray-500 text-gray-900';
        }
    };

    return (
        <Card>
            <h3 className="text-xl font-semibold mb-4 text-white">Historial de Transacciones ({transactions.length})</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                 <select
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value)}
                    className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                >
                    <option value="">Todos los tipos</option>
                    {Object.values(TransactionType).map(type => (
                        <option key={type} value={type}>{type}</option>
                    ))}
                </select>
                <select
                    value={filterUser}
                    onChange={(e) => setFilterUser(e.target.value)}
                    className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                >
                    <option value="">Todos los usuarios</option>
                    {users.map(user => (
                        <option key={user.id} value={user.id}>{user.name}</option>
                    ))}
                </select>
            </div>

            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-700">
                    <thead className="bg-gray-700">
                        <tr>
                            <SortableHeader label="Tipo" sortKey="type" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="Monto" sortKey="amount" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="Fecha/Hora" sortKey="timestamp" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="Usuario" sortKey="userId" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="Tarjeta Cliente" sortKey="customerCardUid" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="Detalles" sortKey="details" sortConfig={sortConfig} onRequestSort={requestSort} />
                        </tr>
                    </thead>
                    <tbody className="bg-gray-800 divide-y divide-gray-700">
                        {paginatedItems.map(tx => (
                            <tr key={tx.id}>
                                <td className="px-6 py-4 whitespace-nowrap">
                                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getTransactionTypeStyles(tx.type)}`}>
                                        {tx.type}
                                    </span>
                                </td>
                                <td className={`px-6 py-4 whitespace-nowrap text-sm font-semibold ${tx.amount > 0 ? 'text-green-400' : 'text-yellow-400'}`}>
                                    {tx.amount > 0 ? `+$${tx.amount.toFixed(2)}` : `-$${Math.abs(tx.amount).toFixed(2)}`}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">{new Date(tx.timestamp).toLocaleString()}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{usersMap.get(tx.userId) || 'N/A'}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-cyan-400">{tx.customerCardUid}</td>
                                <td className="px-6 py-4 whitespace-normal text-sm text-gray-400 max-w-sm">{tx.details || 'N/A'}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {filteredTransactions.length === 0 && <p className="text-center py-4 text-gray-400">No se encontraron transacciones con los filtros aplicados.</p>}
            <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setPage} />
        </Card>
    );
};

export default TransactionsTab;
