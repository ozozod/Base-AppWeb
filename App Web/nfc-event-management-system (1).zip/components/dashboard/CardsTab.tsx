
import React, { useState, useMemo } from 'react';
import { Card as CardType } from '../../types';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { useTable } from '../../hooks/useTable';
import { Pagination } from '../ui/Pagination';
import { SortableHeader } from '../ui/SortableHeader';
import { CardDetailModal } from './CardDetailModal';
import { api } from '../../services/api';

interface CardsTabProps {
    cards: CardType[];
    eventId: string;
    onDataChange: () => void;
}

const CardsTab: React.FC<CardsTabProps> = ({ cards, eventId, onDataChange }) => {
    const [filter, setFilter] = useState('');
    const [updatingCard, setUpdatingCard] = useState<string | null>(null);
    const [isCreateModalOpen, setCreateModalOpen] = useState(false);
    const [newCardData, setNewCardData] = useState({ customerNumber: '', uid: '' });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [selectedCard, setSelectedCard] = useState<CardType | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleToggleStatus = async (card: CardType) => {
        setUpdatingCard(card.uid);
        setError(null);
        try {
            await api.updateCardStatus(eventId, card.uid, !card.isActive);
            onDataChange();
        } catch (err) {
            const message = err instanceof Error ? err.message : 'Failed to update card status.';
            setError(message);
            console.error('Failed to update card status:', err);
        } finally {
            setUpdatingCard(null);
        }
    };

    const handleCreateCard = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        setError(null);
        try {
            await api.createCard(eventId, newCardData.uid, newCardData.customerNumber);
            onDataChange();
            setCreateModalOpen(false);
            setNewCardData({ customerNumber: '', uid: '' });
        } catch (err) {
            const message = err instanceof Error ? err.message : "Failed to create card.";
            setError(message);
            console.error("Failed to create card:", err);
        } finally {
            setIsSubmitting(false);
        }
    };

    const filteredCards = useMemo(() => cards.filter(card => 
        card.uid.toLowerCase().includes(filter.toLowerCase()) ||
        card.customerNumber?.toLowerCase().includes(filter.toLowerCase())
    ), [cards, filter]);

    const { 
        paginatedItems, 
        requestSort, 
        sortConfig, 
        currentPage, 
        totalPages, 
        setPage 
    } = useTable(filteredCards, 'balance', 10, 'descending');

    return (
        <Card>
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-white">Gestión de Compradores ({cards.length})</h3>
                <Button onClick={() => setCreateModalOpen(true)}>Registrar Comprador</Button>
            </div>

            {error && <div className="mb-4 text-red-400 bg-red-900/50 p-3 rounded-md">{error}</div>}

            <div className="mb-4">
                <input
                    type="text"
                    placeholder="Filtrar por UID o Número..."
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                    className="w-full max-w-xs bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                />
            </div>

            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-700">
                    <thead className="bg-gray-700">
                        <tr>
                            <SortableHeader label="UID" sortKey="uid" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="Número" sortKey="customerNumber" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="Saldo" sortKey="balance" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="Estado" sortKey="isActive" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-300 uppercase tracking-wider">Acciones</th>
                        </tr>
                    </thead>
                    <tbody className="bg-gray-800 divide-y divide-gray-700">
                        {paginatedItems.map(card => (
                            <tr key={card.uid} className="hover:bg-gray-700 cursor-pointer" onClick={() => setSelectedCard(card)}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-cyan-400">{card.uid}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{card.customerNumber || 'N/A'}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-white font-semibold">${card.balance.toFixed(2)}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm">
                                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${card.isActive ? 'bg-green-500 text-green-900' : 'bg-red-500 text-red-900'}`}>
                                        {card.isActive ? 'Activa' : 'Bloqueada'}
                                    </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium" onClick={e => e.stopPropagation()}>
                                    <Button 
                                        variant={card.isActive ? 'danger' : 'secondary'}
                                        onClick={() => handleToggleStatus(card)}
                                        disabled={updatingCard === card.uid}
                                    >
                                        {updatingCard === card.uid ? '...' : (card.isActive ? 'Bloquear' : 'Activar')}
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            
            {filteredCards.length === 0 && <p className="text-center py-4 text-gray-400">No se encontraron tarjetas con los filtros aplicados.</p>}
            
            <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setPage} />

            <CardDetailModal card={selectedCard} onClose={() => setSelectedCard(null)} />
        
            <Modal isOpen={isCreateModalOpen} onClose={() => setCreateModalOpen(false)} title="Registrar Nuevo Comprador">
                <form onSubmit={handleCreateCard}>
                     <div className="space-y-4">
                        <div>
                             <label className="block text-sm font-medium text-gray-300 mb-1">Número de Comprador <span className="text-gray-400">(Opcional)</span></label>
                             <input type="text" value={newCardData.customerNumber} onChange={e => setNewCardData({...newCardData, customerNumber: e.target.value})} className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-cyan-500"/>
                        </div>
                        <div>
                             <label className="block text-sm font-medium text-gray-300 mb-1">UID de Tarjeta</label>
                             <input type="text" value={newCardData.uid} onChange={e => setNewCardData({...newCardData, uid: e.target.value.toUpperCase()})} required className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-cyan-500"/>
                        </div>
                     </div>
                     {error && <div className="mt-4 text-red-400 text-sm">{error}</div>}
                     <div className="flex justify-end gap-3 mt-6">
                         <Button type="button" variant="secondary" onClick={() => setCreateModalOpen(false)} disabled={isSubmitting}>Cancelar</Button>
                         <Button type="submit" disabled={isSubmitting || !newCardData.uid.trim()}>{isSubmitting ? 'Registrando...' : 'Registrar Comprador'}</Button>
                     </div>
                </form>
            </Modal>
        </Card>
    );
};

export default CardsTab;
