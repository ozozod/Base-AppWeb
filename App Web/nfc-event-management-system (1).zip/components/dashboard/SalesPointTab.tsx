
import React, { useState, useMemo, useEffect } from 'react';
import { Product, User, Role } from '../../types';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Spinner } from '../ui/Spinner';
import { api } from '../../services/api';

interface SalesPointTabProps {
    products: Product[];
    users: User[];
    eventId: string;
    onDataChange: () => void;
}

interface CartItem extends Product {
    quantity: number;
}

const SalesPointTab: React.FC<SalesPointTabProps> = ({ products, users, eventId, onDataChange }) => {
    const [cart, setCart] = useState<CartItem[]>([]);
    const [customerCardUid, setCustomerCardUid] = useState('');
    const [selectedUserId, setSelectedUserId] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [successMessage, setSuccessMessage] = useState<string | null>(null);

    const activeProducts = useMemo(() => products.filter(p => p.isActive), [products]);
    const salesPersonnel = useMemo(() => users.filter(u => u.isActive && (u.role === Role.VENDOR || u.role === Role.CASHIER)), [users]);

    useEffect(() => {
        if (successMessage) {
            const timer = setTimeout(() => setSuccessMessage(null), 3000);
            return () => clearTimeout(timer);
        }
        if (error) {
            const timer = setTimeout(() => setError(null), 5000);
            return () => clearTimeout(timer);
        }
    }, [successMessage, error]);

    const addToCart = (product: Product) => {
        setCart(prevCart => {
            const existingItem = prevCart.find(item => item.id === product.id);
            if (existingItem) {
                return prevCart.map(item =>
                    item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
                );
            }
            return [...prevCart, { ...product, quantity: 1 }];
        });
    };

    const updateQuantity = (productId: string, newQuantity: number) => {
        if (newQuantity <= 0) {
            setCart(prevCart => prevCart.filter(item => item.id !== productId));
        } else {
            setCart(prevCart => prevCart.map(item =>
                item.id === productId ? { ...item, quantity: newQuantity } : item
            ));
        }
    };
    
    const clearCart = () => {
        setCart([]);
        setCustomerCardUid('');
        setError(null);
        setSuccessMessage(null);
    }

    const totalAmount = useMemo(() => {
        return cart.reduce((total, item) => total + item.price * item.quantity, 0);
    }, [cart]);
    
    const handleCompleteSale = async () => {
        if (!selectedUserId) {
            setError("Por favor, selecciona un vendedor/cajero.");
            return;
        }
        if (cart.length === 0) {
            setError("El carrito está vacío.");
            return;
        }
        if (!customerCardUid.trim()) {
            setError("Por favor, ingresa el UID de la tarjeta del cliente.");
            return;
        }

        setIsLoading(true);
        setError(null);
        setSuccessMessage(null);

        try {
            const details = cart.map(item => `${item.quantity}x ${item.name}`).join(', ');
            await api.createSaleTransaction(eventId, selectedUserId, customerCardUid, totalAmount, details);
            
            setSuccessMessage(`Venta por $${totalAmount.toFixed(2)} completada exitosamente.`);
            clearCart();
            onDataChange(); // Refresh all event data
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'Ocurrió un error desconocido.';
            setError(errorMessage);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Products List */}
            <div className="lg:col-span-2">
                <Card>
                    <h3 className="text-xl font-semibold mb-4 text-white">Productos Disponibles</h3>
                    <div className="mb-4">
                        <select
                            value={selectedUserId}
                            onChange={(e) => setSelectedUserId(e.target.value)}
                            className="w-full max-w-xs bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-cyan-500"
                        >
                            <option value="">-- Seleccionar Vendedor/Cajero --</option>
                            {salesPersonnel.map(user => (
                                <option key={user.id} value={user.id}>{user.name} ({user.role})</option>
                            ))}
                        </select>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {activeProducts.map(product => (
                            <button
                                key={product.id}
                                onClick={() => addToCart(product)}
                                className="bg-gray-700 p-4 rounded-lg text-center hover:bg-cyan-800 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                            >
                                <p className="font-semibold text-white">{product.name}</p>
                                <p className="text-sm text-cyan-400">${product.price.toFixed(2)}</p>
                            </button>
                        ))}
                    </div>
                </Card>
            </div>

            {/* Sale / Cart Panel */}
            <div>
                <Card className="sticky top-24">
                    <h3 className="text-xl font-semibold mb-4 text-white">Venta Actual</h3>
                    <div className="space-y-2 mb-4 max-h-60 overflow-y-auto pr-2">
                        {cart.length === 0 ? (
                            <p className="text-gray-400 text-center py-4">El carrito está vacío</p>
                        ) : (
                            cart.map(item => (
                                <div key={item.id} className="flex justify-between items-center bg-gray-700 p-2 rounded">
                                    <div>
                                        <p className="font-medium text-white">{item.name}</p>
                                        <p className="text-xs text-gray-400">${item.price.toFixed(2)}</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <input
                                            type="number"
                                            min="0"
                                            value={item.quantity}
                                            onChange={(e) => updateQuantity(item.id, parseInt(e.target.value, 10) || 0)}
                                            className="w-12 bg-gray-800 text-center rounded"
                                        />
                                        <p className="w-16 text-right font-semibold text-white">${(item.price * item.quantity).toFixed(2)}</p>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                    
                    <div className="border-t border-gray-700 pt-4 space-y-4">
                        <div className="flex justify-between items-center text-2xl font-bold">
                            <span className="text-gray-300">Total:</span>
                            <span className="text-cyan-400">${totalAmount.toFixed(2)}</span>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">UID Tarjeta Cliente</label>
                            <input
                                type="text"
                                placeholder="Escanee o ingrese UID"
                                value={customerCardUid}
                                onChange={e => setCustomerCardUid(e.target.value.toUpperCase())}
                                className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white font-mono focus:ring-2 focus:ring-cyan-500"
                            />
                        </div>
                        
                        {error && <p className="text-center text-sm text-red-400 bg-red-900/50 p-2 rounded-md">{error}</p>}
                        {successMessage && <p className="text-center text-sm text-green-400 bg-green-900/50 p-2 rounded-md">{successMessage}</p>}
                        
                        <div className="grid grid-cols-2 gap-3">
                            <Button variant="danger" onClick={clearCart} disabled={isLoading}>
                                Limpiar
                            </Button>
                            <Button onClick={handleCompleteSale} disabled={isLoading || cart.length === 0 || !selectedUserId}>
                                {isLoading ? <Spinner className="h-5 w-5 mx-auto" /> : 'Completar Venta'}
                            </Button>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default SalesPointTab;
