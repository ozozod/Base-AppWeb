
import React, { useState } from 'react';
import { User, Role, Transaction } from '../../types';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { useTable } from '../../hooks/useTable';
import { Pagination } from '../ui/Pagination';
import { SortableHeader } from '../ui/SortableHeader';
import { UserDetailModal } from './UserDetailModal';
import { api } from '../../services/api';

interface UsersTabProps {
    users: User[];
    transactions: Transaction[];
    eventId: string;
    onDataChange: () => void;
}

const UsersTab: React.FC<UsersTabProps> = ({ users, transactions, eventId, onDataChange }) => {
    const [isModalOpen, setModalOpen] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [newUser, setNewUser] = useState({ name: '', role: Role.VENDOR, cardUid: '', employeeNumber: '' });
    const [selectedUser, setSelectedUser] = useState<User | null>(null);
    const [error, setError] = useState<string | null>(null);

    const { 
        paginatedItems, 
        requestSort, 
        sortConfig, 
        currentPage, 
        totalPages, 
        setPage 
    } = useTable(users, 'name', 10);

    const handleCreateUser = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        setError(null);
        try {
            await api.createUser(eventId, newUser.name, newUser.role, newUser.cardUid, newUser.employeeNumber);
            onDataChange();
            setModalOpen(false);
            setNewUser({ name: '', role: Role.VENDOR, cardUid: '', employeeNumber: '' });
        } catch (err) {
            const message = err instanceof Error ? err.message : "Failed to create user.";
            setError(message);
            console.error("Failed to create user:", err);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleToggleActive = async (user: User) => {
        try {
            setError(null);
            await api.updateUser(user.id, { isActive: !user.isActive });
            onDataChange();
        } catch (err) {
            const message = err instanceof Error ? err.message : "Failed to update user status.";
            setError(message);
            console.error("Failed to update user status:", err);
        }
    }

    return (
        <Card>
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-white">Gestión de Personal ({users.length})</h3>
                <Button onClick={() => setModalOpen(true)}>Crear Usuario</Button>
            </div>
            
            {error && <div className="mb-4 text-red-400 bg-red-900/50 p-3 rounded-md">{error}</div>}

             <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-700">
                    <thead className="bg-gray-700">
                        <tr>
                            <SortableHeader label="Nombre" sortKey="name" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="Número" sortKey="employeeNumber" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="Rol" sortKey="role" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="UID Tarjeta" sortKey="cardUid" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <SortableHeader label="Estado" sortKey="isActive" sortConfig={sortConfig} onRequestSort={requestSort} />
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-300 uppercase tracking-wider">Acciones</th>
                        </tr>
                    </thead>
                    <tbody className="bg-gray-800 divide-y divide-gray-700">
                        {paginatedItems.map(user => (
                            <tr key={user.id} className="hover:bg-gray-700 cursor-pointer" onClick={() => setSelectedUser(user)}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-white">{user.name}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{user.employeeNumber || 'N/A'}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{user.role}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-cyan-400">{user.cardUid}</td>
                                 <td className="px-6 py-4 whitespace-nowrap text-sm">
                                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${user.isActive ? 'bg-green-500 text-green-900' : 'bg-gray-600 text-gray-200'}`}>
                                        {user.isActive ? 'Activo' : 'Inactivo'}
                                    </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium" onClick={e => e.stopPropagation()}>
                                     <Button variant={user.isActive ? 'secondary' : 'primary'} onClick={() => handleToggleActive(user)}>
                                        {user.isActive ? 'Desactivar' : 'Activar'}
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setPage} />

            <UserDetailModal user={selectedUser} transactions={transactions} onClose={() => setSelectedUser(null)} />

            <Modal isOpen={isModalOpen} onClose={() => setModalOpen(false)} title="Crear Nuevo Usuario de Personal">
                <form onSubmit={handleCreateUser}>
                     <div className="space-y-4">
                        <div>
                             <label className="block text-sm font-medium text-gray-300 mb-1">Nombre</label>
                             <input type="text" value={newUser.name} onChange={e => setNewUser({...newUser, name: e.target.value})} required className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-cyan-500"/>
                        </div>
                        <div>
                             <label className="block text-sm font-medium text-gray-300 mb-1">Rol</label>
                             <select value={newUser.role} onChange={e => setNewUser({...newUser, role: e.target.value as Role})} className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-cyan-500">
                                {Object.values(Role).map(r => <option key={r} value={r}>{r}</option>)}
                             </select>
                        </div>
                        <div>
                             <label className="block text-sm font-medium text-gray-300 mb-1">Número de Empleado</label>
                             <input type="text" value={newUser.employeeNumber} onChange={e => setNewUser({...newUser, employeeNumber: e.target.value})} className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-cyan-500"/>
                        </div>
                        <div>
                             <label className="block text-sm font-medium text-gray-300 mb-1">UID de Tarjeta Asociada</label>
                             <input type="text" value={newUser.cardUid} onChange={e => setNewUser({...newUser, cardUid: e.target.value.toUpperCase()})} required className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-cyan-500"/>
                        </div>
                     </div>
                     {error && <div className="mt-4 text-red-400 text-sm">{error}</div>}
                     <div className="flex justify-end gap-3 mt-6">
                         <Button type="button" variant="secondary" onClick={() => setModalOpen(false)} disabled={isSubmitting}>Cancelar</Button>
                         <Button type="submit" disabled={isSubmitting}>{isSubmitting ? 'Creando...' : 'Crear Usuario'}</Button>
                     </div>
                </form>
            </Modal>
        </Card>
    );
};

export default UsersTab;
