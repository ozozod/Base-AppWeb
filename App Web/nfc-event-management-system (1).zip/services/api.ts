import { Event, User, Card, Transaction, Product, Role } from '../types';

// Usamos una URL relativa para que funcione el proxy de Vite.
// No necesita el '/api' aquí porque las llamadas lo incluyen.
const BASE_URL = ''; 

// Error personalizado para respuestas de la API
class ApiError extends Error {
    constructor(message: string, public status?: number) {
        super(message);
        this.name = 'ApiError';
    }
}

// Wrapper de Fetch centralizado
async function apiFetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${BASE_URL}${endpoint}`;
    const defaultOptions: RequestInit = {
        headers: { 'Content-Type': 'application/json' },
    };

    const response = await fetch(url, { ...defaultOptions, ...options });

    if (!response.ok) {
        let errorMessage = `HTTP error! status: ${response.status}`;
        try {
            const errorBody = await response.json();
            errorMessage = errorBody.error || errorMessage;
        } catch (e) { /* No es JSON, usar mensaje por defecto */ }
        throw new ApiError(errorMessage, response.status);
    }

    if (response.status === 204) {
        return null as T;
    }

    return response.json() as Promise<T>;
}

export const api = {
    // --- Eventos ---
    getEvents: () => apiFetch<Event[]>('/api/events'),
    getActiveEvent: () => apiFetch<Event>('/api/events/active'),
    createEvent: (name: string) => apiFetch<Event>('/api/events', {
        method: 'POST',
        body: JSON.stringify({ name }),
    }),
    updateEventStatus: (eventId: string, status: 'activo' | 'finalizado') => apiFetch<void>(`/api/events/${eventId}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status }),
    }),
    deleteEvent: (eventId: string) => apiFetch<void>(`/api/events/${eventId}`, {
        method: 'DELETE',
    }),

    // --- Detalles del Evento (CORREGIDO Y EFICIENTE) ---
    getEventDetails: (eventId: string) => apiFetch<{ event: Event, users: User[], cards: Card[], transactions: Transaction[], products: Product[] }>(`/api/events/${eventId}/details`),

    // --- Personal (Users) ---
    createUser: (eventId: string, name: string, role: Role, cardUid: string, employeeNumber?: string) => apiFetch<User>(`/api/events/${eventId}/users`, {
        method: 'POST',
        body: JSON.stringify({ name, role, cardUid, employeeNumber }),
    }),
    updateUser: (userId: string, updates: Partial<Pick<User, 'isActive'>>) => apiFetch<User>(`/api/users/${userId}`, {
        method: 'PATCH',
        body: JSON.stringify(updates),
    }),

    // --- Compradores (Cards) ---
    createCard: (eventId: string, uid: string, customerNumber?: string) => apiFetch<Card>(`/api/events/${eventId}/cards`, {
        method: 'POST',
        body: JSON.stringify({ uid, customerNumber }),
    }),
    updateCardStatus: (eventId: string, cardUid: string, isActive: boolean) => apiFetch<Card>(`/api/events/${eventId}/cards/${cardUid}`, {
        method: 'PATCH',
        body: JSON.stringify({ isActive }),
    }),

    // --- Productos ---
    createProduct: (eventId: string, name: string, price: number) => apiFetch<Product>(`/api/events/${eventId}/products`, {
        method: 'POST',
        body: JSON.stringify({ name, price }),
    }),
    updateProduct: (productId: string, updates: Partial<Product>) => apiFetch<Product>(`/api/products/${productId}`, {
        method: 'PATCH',
        body: JSON.stringify(updates),
    }),

    // --- Transacciones (CORREGIDO) ---
    createSaleTransaction: (eventId: string, staffId: string, customerUid: string, amount: number, details: string) => apiFetch<Transaction>('/api/transactions/sale', {
        method: 'POST',
        body: JSON.stringify({ eventId, staffId, customerUid, amount, details }),
    }),
    createRechargeTransaction: (eventId: string, staffId: string, customerUid: string, amount: number, paymentMethod: string) => apiFetch<Transaction>('/api/transactions/recharge', {
        method: 'POST',
        body: JSON.stringify({ eventId, staffId, customerUid, amount, paymentMethod }),
    }),
    createRefundTransaction: (eventId: string, staffId: string, customerUid: string, amount: number) => apiFetch<Transaction>('/api/transactions/refund', {
        method: 'POST',
        body: JSON.stringify({ eventId, staffId, customerUid, amount }),
    }),
};
