import { defineConfig, loadEnv } from 'vite';
import { fileURLToPath, URL } from 'node:url';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    return {
      plugins: [react()],
      define: {
        'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY),
        'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY)
      },
      resolve: {
        alias: {
          '@': fileURLToPath(new URL('.', import.meta.url)),
        }
      },
      server: {
        host: true, // Allow connections from other devices on the network
        proxy: {
          // Proxy API requests to the local backend server
          '/api': {
            target: 'http://localhost:3000', // Backend server address
            changeOrigin: true,
            secure: false,
            // The rewrite rule has been removed.
            // A request to /api/events will now be forwarded to http://localhost:3000/api/events
          },
        },
      },
    };
});
