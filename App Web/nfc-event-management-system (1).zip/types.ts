export enum Role {
    CASHIER = 'CAJERO',
    VENDOR = 'VENDEDOR',
    MANAGER = 'ENCARGADO',
    ADMINISTRATOR = 'ADMINISTRADOR',
}

export enum TransactionType {
    RELOAD = 'Recarga',
    SALE = 'Venta',
    VOID = 'Anulación',
    DEVOLUTION = 'Devolución',
}

export interface User {
    id: string;
    eventId: string;
    name: string;
    employeeNumber?: string;
    role: Role;
    cardUid: string;
    isActive: boolean;
}

export interface Card {
    uid: string;
    eventId: string;
    customerNumber?: string;
    balance: number;
    isActive: boolean;
    history: Transaction[];
}

export interface Transaction {
    id: string;
    eventId: string;
    type: TransactionType;
    amount: number;
    timestamp: Date;
    userId: string; // Vendedor/Cajero
    customerCardUid: string;
    details?: string; // e.g., items for a sale, original transaction ID for a void
}

export interface Event {
    id: string;
    name: string;
    status: 'activo' | 'finalizado';
    createdAt: Date;
}

export interface Product {
    id: string;
    eventId: string;
    name: string;
    price: number;
    isActive: boolean;
}